# animal_shelter.py

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, user, password, host, port, db, collection):
        """Initialize connection to MongoDB"""
        self.client = MongoClient(f"mongodb://{user}:{password}@{host}:{port}")
        self.database = self.client[db]
        self.collection = self.database[collection]

    def create(self, data):
        """Inserts a document into the MongoDB collection"""
        if data:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        else:
            raise ValueError("Data cannot be empty")

    def read(self, query):
        """Queries documents from the MongoDB collection"""
        if query:
            result = list(self.collection.find(query))
            return result if result else []
        else:
            raise ValueError("Query parameter cannot be empty")

    def update(self, query, new_values):
        """Updates documents in the MongoDB collection"""
        if query and new_values:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        else:
            raise ValueError("Query and update values cannot be empty")

    def delete(self, query):
        """Deletes documents from the MongoDB collection"""
        if query:
            result = self.collection.delete_many(query)
            return result.deleted_count
        else:
            raise ValueError("Query parameter cannot be empty")

